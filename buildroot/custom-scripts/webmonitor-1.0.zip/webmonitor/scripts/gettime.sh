#!/bin/sh
#
# Prints the current system time: hour:minute:seconds
#
date +%H:%M:%S
