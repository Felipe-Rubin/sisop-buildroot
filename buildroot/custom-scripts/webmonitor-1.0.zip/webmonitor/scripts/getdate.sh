#!/bin/sh
#
# Prints the current system date: day/month/year
#
date +%d/%m/%Y
