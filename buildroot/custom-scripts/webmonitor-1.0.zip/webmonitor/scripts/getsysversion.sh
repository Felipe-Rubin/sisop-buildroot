#!/bin/sh
#
# Get System version
#
#
cat /proc/version
