
## Assignment  \#1 
- University: PUCRS
- School: Polytechnic, Computer Science
- Course: Lab Sisop
- Semester:  2018/1

## Authors: 
- [Felipe Pfeifer Rubin](felipe.rubin@acad.pucrs.br)
- [Guilherme Girotto](guilherme.girotto@acad.pucrs.br)

## Execution
```sh
python start.py
```